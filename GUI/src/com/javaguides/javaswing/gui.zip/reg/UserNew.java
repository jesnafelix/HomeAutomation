package com.javaguides.javaswing.reg;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JScrollPane;
import javax.swing.JMenu;
import java.awt.event.ContainerAdapter;
import java.awt.event.ContainerEvent;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.FlowLayout;

public class UserNew {

	private JFrame frmSmartHomeAutomation;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UserNew window = new UserNew();
					window.frmSmartHomeAutomation.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public UserNew() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmSmartHomeAutomation = new JFrame();
		frmSmartHomeAutomation.getContentPane().addContainerListener(new ContainerAdapter() {
			@Override
			public void componentAdded(ContainerEvent e) {
			}
		});
		frmSmartHomeAutomation.setTitle("SMART HOME AUTOMATION");
		frmSmartHomeAutomation.setBounds(100, 100, 897, 714);
		frmSmartHomeAutomation.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmSmartHomeAutomation.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 369, 101, 34);
		frmSmartHomeAutomation.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(10, 414, 101, 34);
		frmSmartHomeAutomation.getContentPane().add(panel_2);
		panel_2.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JPanel panel_3 = new JPanel();
		panel_3.setBounds(10, 472, 101, 34);
		frmSmartHomeAutomation.getContentPane().add(panel_3);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBounds(10, 540, 101, 34);
		frmSmartHomeAutomation.getContentPane().add(panel_4);
		
		JLabel lblNewLabel = new JLabel("IP Address");
		lblNewLabel.setBounds(10, 64, 101, 29);
		frmSmartHomeAutomation.getContentPane().add(lblNewLabel);
		
		JLabel lblPortNumber = new JLabel("Port Number");
		lblPortNumber.setBounds(523, 64, 101, 29);
		frmSmartHomeAutomation.getContentPane().add(lblPortNumber);
		
		textField = new JTextField();
		textField.setBounds(124, 57, 181, 43);
		frmSmartHomeAutomation.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(623, 57, 181, 43);
		frmSmartHomeAutomation.getContentPane().add(textField_1);
		
		JButton btnNewButton = new JButton("CONNECT");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setBounds(177, 156, 138, 29);
		frmSmartHomeAutomation.getContentPane().add(btnNewButton);
		
		JButton btnDisconnect = new JButton("DISCONNECT");
		btnDisconnect.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnDisconnect.setBounds(478, 156, 138, 29);
		frmSmartHomeAutomation.getContentPane().add(btnDisconnect);
	}
}
